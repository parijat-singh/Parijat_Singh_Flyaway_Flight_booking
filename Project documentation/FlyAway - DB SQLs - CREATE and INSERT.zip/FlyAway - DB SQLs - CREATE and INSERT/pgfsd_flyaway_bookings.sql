-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: localhost    Database: pgfsd_flyaway
-- ------------------------------------------------------
-- Server version	8.0.25

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bookings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `flight_id` int DEFAULT NULL,
  `num_of_seats` int DEFAULT NULL,
  `payer_name` varchar(45) DEFAULT NULL,
  `payer_zip` varchar(45) DEFAULT NULL,
  `creditcard_num` varchar(45) DEFAULT NULL,
  `expiration` varchar(45) DEFAULT NULL,
  `total_payment_amount` float DEFAULT NULL,
  `passenger1_name` varchar(45) DEFAULT NULL,
  `passenger1_gender` varchar(45) DEFAULT NULL,
  `passenger1_dob` varchar(45) DEFAULT NULL,
  `passenger2_name` varchar(45) DEFAULT NULL,
  `passenger2_gender` varchar(45) DEFAULT NULL,
  `passenger2_dob` varchar(45) DEFAULT NULL,
  `passenger3_name` varchar(45) DEFAULT NULL,
  `passenger3_gender` varchar(45) DEFAULT NULL,
  `passenger3_dob` varchar(45) DEFAULT NULL,
  `passenger4_name` varchar(45) DEFAULT NULL,
  `passenger4_gender` varchar(45) DEFAULT NULL,
  `passenger4_dob` varchar(45) DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookings`
--

LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
INSERT INTO `bookings` VALUES (1,1,4,'bob','12345','1234567890123456','12/25',1400,'joe','male','1980-01-23','diana','female','1976-03-05','mary','female','1985-04-24','amit','male','2012-04-05','2021-06-10 06:41:39'),(2,39,1,'amiss','23456','0123456789123456','1/2027',375,'amiss','male','1981-06-09','','','','','','','','','','2021-06-10 08:21:31'),(3,39,1,'amiss','23456','1234567890098765','10/2021',375,'wdq','female','2020-07-07','','','','','','','','','','2021-06-10 09:19:56'),(4,26,1,'aditi','23459','1234567891234567','1/2021',350,'amiss','female','2021-06-23','','','','','','','','','','2021-06-10 09:37:26'),(5,39,2,'jhvasd','34567','1234512345123451','1/2028',750,'wrfer','male','2021-06-01','ewrfe','female','1991-02-05','','','','','','','2021-06-10 10:17:50'),(6,39,4,'iohoasdfj','23456','5678345609873456','1/2021',1500,'sefewrg','male','2021-06-08','efgwrg','female','2021-06-08','edgfewgr','male','2021-06-23','ergewrg','male','2021-06-01','2021-06-10 10:20:51'),(7,39,1,'sdds','23456','1234567890123456','1/2021',375,'amiss','female','2021-06-01','','','','','','','','','','2021-06-10 12:15:31'),(8,39,1,'sdds','23456','1234567890123456','1/2021',375,'amiss','female','2021-06-01','','','','','','','','','','2021-06-10 12:15:49'),(9,39,1,'sdds','23456','1234567890123456','1/2021',375,'amiss','female','2021-06-01','','','','','','','','','','2021-06-10 12:15:59'),(10,39,1,'sdds','23456','1234567890123456','1/2021',375,'amiss','female','2021-06-01','','','','','','','','','','2021-06-10 12:16:22'),(11,39,1,'sdds','23456','1234567890123456','1/2021',375,'amiss','female','2021-06-01','','','','','','','','','','2021-06-10 12:22:31'),(12,39,1,'sdds','23456','1234567890123456','1/2021',375,'amiss','female','2021-06-01','','','','','','','','','','2021-06-10 12:22:35'),(13,22,1,'sdfsf','23456','1234567890123456','1/2021',350,'amiss','female','2021-06-22','','','','','','','','','','2021-06-10 12:23:59'),(14,22,1,'sdfsf','23456','1234567890123456','1/2021',350,'amiss','female','2021-06-22','','','','','','','','','','2021-06-10 12:24:05'),(15,22,1,'sdfsf','23456','1234567890123456','1/2021',350,'amiss','female','2021-06-22','','','','','','','','','','2021-06-10 12:32:59'),(16,23,1,'sdds','23456','1234567890123456','1/2021',350,'sfwef','female','2021-06-02','','','','','','','','','','2021-06-10 12:44:14'),(17,23,1,'sdds','23456','1234567890123456','1/2021',350,'sfwef','female','2021-06-02','','','','','','','','','','2021-06-10 12:44:22'),(18,30,1,'sfef','27539','1234567890123456','1/2021',350,'srrg','female','2021-06-21','','','','','','','','','','2021-06-10 17:00:44');
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-06-10 19:15:42
